<template>
  <div class="msg-panel" :class="{ 'msg-panel-static': isStatic }">
    <div v-if="!conversation" class="msg-empty">
      <div class="msg-empty-icon">💬</div>
      <div>选择一个会话查看聊天记录</div>
    </div>
    <template v-else>
      <div class="msg-header" v-if="!isStatic">
        <h3>{{ conversation.name || '未命名' }}</h3>
        <span class="msg-total">{{ total }} 条消息</span>
        <button v-if="!selfUid && senders.length === 2" class="msg-pick-self" @click="showPicker = true">
          设置"我"
        </button>
        <button v-if="selfUid" class="msg-pick-self picked" @click="showPicker = true">
          我: {{ selfUid.slice(-4) }}
        </button>
      </div>

      <div v-if="referenceError" role="status" class="msg-loading" @click="referenceError = ''">{{ referenceError }}</div>

      <!-- UID 选择弹窗 -->
      <div v-if="showPicker" class="picker-overlay" @click.self="showPicker = false">
        <div class="picker-dialog">
          <div class="picker-title">选择哪个是你自己</div>
          <div class="picker-hint">选择后消息会区分左右显示</div>
          <div
            v-for="s in senders"
            :key="s.sender_uid"
            class="picker-option"
            :class="{ active: selfUid === s.sender_uid }"
            @click="pickSelf(s.sender_uid)"
          >
            <span class="picker-uid">{{ userCache[s.sender_uid]?.nickname || ('UID ...' + s.sender_uid.slice(-6)) }}</span>
            <span class="picker-count">{{ s.msg_count }} 条消息</span>
          </div>
          <button v-if="selfUid" class="picker-clear" @click="pickSelf(null)">清除选择</button>
        </div>
      </div>

      <button v-if="!isStatic && hasOlder" class="msg-jump-fab msg-jump-top" @click="jumpToTop">
        ↑ 最早消息
      </button>
      <button v-if="!isStatic && hasNewer" class="msg-jump-fab msg-jump-bottom" @click="jumpToBottom">
        ↓ 最新消息
      </button>
      <div class="msg-list" :class="{ 'msg-list-static': isStatic }" ref="listRef">
        <div v-if="loading" class="msg-loading">加载中...</div>
        <div v-else-if="loadError" role="alert" class="msg-loading">
          {{ loadError }} <button @click="fetchMessages(conversation.conv_id)">重试</button>
        </div>
        <div v-if="hasOlder && !loading" class="msg-load-more" @click="loadOlder">
          ⬆ 加载更早消息
        </div>
        <template v-for="(msg, index) in messages" :key="msg.msg_id">
        <div
          v-if="shouldShow(msg) && !duplicateSystemIds.has(msg.msg_id)"
          class="msg-item"
          :data-msgid="msg.msg_id"
          :class="{
            'msg-self': isSelf(msg),
            'msg-system': isSystemMsg(msg),
            'msg-highlight': highlightMsgId === msg.msg_id,
            'group-start': isGroupStart(index),
            'msg-grouped': !isGroupStart(index),
          }"
        >
          <!-- 系统消息居中显示 -->
          <template v-if="isSystemMsg(msg)">
            <div class="msg-system-block">
              <!-- 一起看视频邀请卡片 (aweType=9000) -->
              <div v-if="getWatchTogether(msg)" class="msg-watch-card">
                <div class="msg-watch-icon">▶</div>
                <div class="msg-watch-body">
                  <div class="msg-watch-title">{{ getWatchTogether(msg).title }}</div>
                  <div v-if="getWatchTogether(msg).subtitle" class="msg-watch-sub">{{ getWatchTogether(msg).subtitle }}</div>
                </div>
              </div>
              <div v-else class="msg-system-text" @contextmenu="selectSystemContent">{{ renderSystemMsg(msg, selfUid) }}</div>
              <!-- 引用的分享视频卡片 -->
              <div
                v-if="sysRefCache[msg.msg_id]"
                class="msg-system-ref"
                @click="openSystemReference(msg)"
              >
                <img
                  v-if="sysRefCache[msg.msg_id].cover"
                  :src="sysRefCache[msg.msg_id].cover"
                  class="msg-system-ref-cover"
                  @error="onImgError"
                />
                <span class="msg-system-ref-title">{{ sysRefCache[msg.msg_id].title }}</span>
              </div>
            </div>
          </template>
          <!-- 普通消息 -->
          <template v-else>
            <div class="msg-avatar" :class="{ 'msg-avatar-img': getAvatarUrl(msg) }">
              <img v-if="getAvatarUrl(msg)" :src="getAvatarUrl(msg)" @error="onImgError" />
              <span v-else :style="{ background: isSelf(msg) ? 'var(--accent)' : 'var(--bg-tertiary)', color: isSelf(msg) ? '#fff' : 'var(--text-secondary)' }">{{ displayName(msg)[0] }}</span>
            </div>
            <div class="msg-body" @contextmenu="selectMsgContent">
              <div class="msg-sender">{{ displayName(msg) }}</div>
              <!-- 引用/回复消息 -->
              <div v-if="getRefMsg(msg)" class="msg-ref-quote" @click="jumpToRefMsg(getRefMsg(msg))">
                <span v-if="getRefNickname(getRefMsg(msg))" class="msg-ref-name">{{ getRefNickname(getRefMsg(msg)) }}：</span>
                <span class="msg-ref-content">{{ getRefContent(getRefMsg(msg)) }}</span>
              </div>
              <a v-if="getProfileCard(msg)" class="msg-profile-card" :href="getProfileCard(msg).url" target="_blank" rel="noopener noreferrer">
                <img v-if="getProfileCard(msg).avatar" :src="getProfileCard(msg).avatar" alt="用户头像" :loading="imgLoading" @error="onImgError" />
                <div><strong>{{ getProfileCard(msg).name }}</strong>
                  <div v-if="getProfileCard(msg).description">抖音号：{{ getProfileCard(msg).description }}</div>
                  <div v-if="getProfileCard(msg).followers !== null">粉丝：{{ getProfileCard(msg).followers }}</div>
                  <small>用户名片 · 查看主页</small>
                </div>
              </a>
              <ForwardRecords v-else-if="getForwardInfo(msg)" :message="msg" :selfUid="selfUid" />
              <!-- 表情包（含 type=0 的 515/517/520 漏网） -->
              <div v-else-if="(msg.msg_type === 2 || isLooseEmoji(msg)) && getEmojiSrc(msg)" class="msg-media">
                <img :src="getEmojiSrc(msg)" :alt="msg.content" :loading="imgLoading" @click="openLightbox(getEmojiSrc(msg))" @error="onImgError" />
              </div>
              <div v-else-if="isLooseEmoji(msg)" class="msg-media">
                <div class="msg-media-missing">[表情]</div>
              </div>
              <!-- 图片/视频：优先本地原文件，回退到 inline_pic 缩略图 -->
              <div v-else-if="msg.msg_type === 3 || isLooseImage(msg)" class="msg-media">
                <video
                  v-if="isVideoMsg(msg)"
                  :src="'/media/' + msg.media_local_path"
                  controls
                  preload="metadata"
                  :poster="getInlinePic(msg)"
                />
                <img
                  v-else-if="getImageSrc(msg)"
                  :src="getImageSrc(msg)"
                  alt="图片"
                  :loading="imgLoading"
                  @click="openLightbox(getImageSrc(msg))"
                />
                <div v-else class="msg-media-missing">[图片已失效]</div>
              </div>
              <!-- 分享卡片（含 type=0/1 漏网的作品/地点/直播卡） -->
              <div
                v-else-if="isShareCard(msg)"
                class="msg-share-card"
                @click="openShare(msg)"
              >
                <div v-if="getShareInfo(msg).comment || getShareInfo(msg).commentImg" class="msg-share-comment">
                  <span v-if="getShareInfo(msg).commentUser" class="msg-share-comment-user">{{ getShareInfo(msg).commentUser }}：</span>{{ getShareInfo(msg).comment }}
                  <img v-if="getShareInfo(msg).commentImg" :src="getShareInfo(msg).commentImg" class="msg-share-comment-img" :loading="imgLoading" @error="onImgError" />
                </div>
                <div class="msg-share-card-inner">
                  <div class="msg-share-card-body">
                    <div class="msg-share-card-title">{{ getShareInfo(msg).title || '[分享]' }}</div>
                    <div v-if="getShareInfo(msg).author" class="msg-share-card-author">
                      @ {{ getShareInfo(msg).author }}
                    </div>
                  </div>
                  <img
                    v-if="getShareInfo(msg).cover"
                    :src="getShareInfo(msg).cover"
                    class="msg-share-card-cover"
                    :loading="imgLoading"
                    @error="onImgError"
                  />
                </div>
              </div>
              <!-- 视频消息：本地有 .mp4 → 真播放；否则展示封面 + 时长 -->
              <div v-else-if="isJsonVideo(msg)" class="msg-media msg-video-poster">
                <video
                  v-if="hasLocalVideo(msg)"
                  :src="'/media/' + msg.media_local_path"
                  :poster="getVideoPoster(msg)"
                  controls
                  preload="none"
                  class="msg-video-player"
                />
                <template v-else>
                  <img
                    v-if="getVideoPoster(msg)"
                    :src="getVideoPoster(msg)"
                    :loading="imgLoading"
                    @click="openLightbox(getVideoPoster(msg))"
                  />
                  <div v-else class="msg-media-missing">[视频]</div>
                  <div class="msg-video-overlay">
                    <span class="msg-video-play">▶</span>
                    <span v-if="getVideoDuration(msg)" class="msg-video-dur">{{ getVideoDuration(msg) }}</span>
                  </div>
                </template>
              </div>
              <!-- 语音消息 -->
              <div v-else-if="isVoiceMsg(msg)" class="msg-bubble msg-voice-bubble">
                <div class="msg-voice-player" :class="{ playing: isVoicePlaying(msg) }">
                  <button
                    type="button"
                    class="msg-voice-play"
                    :class="{ playing: isVoicePlaying(msg) }"
                    :disabled="!getVoiceUrl(msg)"
                    :aria-label="isVoicePlaying(msg) ? '暂停语音' : '播放语音'"
                    @click.stop="toggleVoice(msg)"
                  >
                    <svg v-if="!isVoicePlaying(msg)" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8 5.2v13.6a1 1 0 0 0 1.55.83l9.25-6.8a1 1 0 0 0 0-1.66l-9.25-6.8A1 1 0 0 0 8 5.2Z" />
                    </svg>
                    <svg v-else viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M7 5.5h3.4v13H7v-13Zm6.6 0H17v13h-3.4v-13Z" />
                    </svg>
                  </button>
                  <span class="msg-voice-wave" aria-hidden="true">
                    <i v-for="n in 13" :key="n"></i>
                  </span>
                  <span class="msg-voice-dur">{{ getVoiceDuration(msg) }}″</span>
                  <audio
                    :ref="el => setVoiceAudioRef(msg.msg_id, el)"
                    preload="none"
                    :src="getVoiceUrl(msg)"
                    @ended="onVoiceEnded(msg.msg_id)"
                  ></audio>
                </div>
                <div v-if="msg.voice_transcription" class="msg-voice-divider"></div>
                <div v-if="msg.voice_transcription" class="msg-voice-transcript">
                  <span v-html="highlightText(msg.voice_transcription)"></span>
                </div>
              </div>
              <!-- 评论引用视频（aweType=700，文本+关联视频） -->
              <div v-else-if="isVideoComment(msg)" class="msg-share-card" @click="openVideoReference(msg)">
                <div class="msg-share-comment" v-html="highlightText(msg.content)"></div>
                <div class="msg-share-card-inner msg-share-card-ref">
                  <span class="msg-share-card-ref-icon">▶</span>
                  <span class="msg-share-card-ref-text">引用的视频</span>
                </div>
              </div>
              <!-- 文本消息 -->
              <div v-else class="msg-bubble" v-html="highlightText(msg.content)"></div>
              <div class="msg-time">
                <span v-if="isRecalled(msg)" class="msg-recalled-tag">已撤回</span>
                {{ formatTime(msg.timestamp) }}
              </div>
            </div>
          </template>
        </div>
        </template>
        <div v-if="hasNewer && !loading" class="msg-load-more" @click="loadNewer">
          ⬇ 加载更新消息
        </div>
        <div v-if="messages.length === 0 && !loading && !loadError" class="msg-no-data">
          暂无消息
        </div>
      </div>
    </template>

    <MessageLightbox v-model="lightboxSrc" />
  </div>
</template>

<script setup>
import { ref, reactive, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
import { highlightText as _highlightText } from '@/lib/highlight'
import { resolveAvatarUrl } from '@/lib/media'
import MessageLightbox from './MessageLightbox.vue'
import {
  clearCjCache, getContentJson, tryParseJson, tryParseShareContent, extractShareTitle,
  isJsonSystemMsg, shouldShow, renderSystemMsg, getWatchTogether, getProfileCard, getForwardInfo, isSystemMsg, duplicateSystemMessageIds,
  extractServerMsgIds, isVideoComment, isLooseEmoji, isLooseImage, isShareCard, getShareInfo, getInlinePic,
  isVideoMsg, hasLocalVideo, isJsonVideo, getVideoPoster, getVideoDuration,
  getImageSrc, getEmojiSrc, isRecalled, isVoiceMsg, getVoiceUrl, getVoiceDuration,
  getRefMsg, getRefContent, getRefNickname,
} from '@/lib/douyinMessage'

import ForwardRecords from './ForwardRecords.vue'

const props = defineProps({
  conversation: Object,
  searchHighlight: String,
  jumpToSeq: Number,
  // 截图模式：只加载 [startSeq, endSeq] 区间，隐藏交互 chrome，不绑定滚动
  staticRange: Object,
  embeddedMessages: Array,
  selfUidOverride: String,
})
const emit = defineEmits(['jumped', 'staticLoaded'])

const messages = ref([])
const total = ref(0)
const loading = ref(false)
let scrollLocked = false  // 防止程序化滚动触发无限加载
const hasOlder = ref(false)
const hasNewer = ref(false)
const listRef = ref(null)
const senders = ref([])
const selfUid = ref(props.selfUidOverride || localStorage.getItem('selfUid') || '')
const showPicker = ref(false)
const isStatic = computed(() => !!props.staticRange || !!props.embeddedMessages)
const duplicateSystemIds = computed(() => duplicateSystemMessageIds(messages.value))
const imgLoading = computed(() => (isStatic.value ? 'eager' : 'lazy'))

// 用户信息缓存 { uid: { nickname, avatar_url, unique_id } }
const userCache = reactive({})

// Keep native audio elements behind the compact voice bubble and allow only
// one voice message to play at a time.
const voiceAudioRefs = new Map()
const playingVoiceId = ref(null)

function setVoiceAudioRef(msgId, el) {
  if (el) voiceAudioRefs.set(msgId, el)
  else voiceAudioRefs.delete(msgId)
}

function isVoicePlaying(msg) {
  return playingVoiceId.value === msg.msg_id
}

async function toggleVoice(msg) {
  const audio = voiceAudioRefs.get(msg.msg_id)
  if (!audio || !getVoiceUrl(msg)) return
  if (!audio.paused) {
    audio.pause()
    playingVoiceId.value = null
    return
  }
  for (const [msgId, other] of voiceAudioRefs) {
    if (msgId !== msg.msg_id && !other.paused) other.pause()
  }
  try {
    await audio.play()
    playingVoiceId.value = msg.msg_id
  } catch {
    playingVoiceId.value = null
  }
}

function onVoiceEnded(msgId) {
  if (playingVoiceId.value === msgId) playingVoiceId.value = null
}

// content_json 解析缓存
// 系统消息引用的分享视频缓存 { msg_id: { title, cover, itemId } }
const sysRefCache = reactive({})

function isSelf(msg) {
  if (!selfUid.value) return false
  return msg.sender_uid === selfUid.value
}

function _isSystem(msg) {
  return isSystemMsg(msg)
}

// A message starts a new visual group unless it continues the previous
// message's sender within a short window. Grouped messages hide the repeated
// avatar + name and sit tighter. System messages always break a group.
function isGroupStart(index) {
  if (index <= 0) return true
  const cur = messages.value[index]
  const prev = messages.value[index - 1]
  if (!prev || _isSystem(cur) || _isSystem(prev)) return true
  if (prev.sender_uid !== cur.sender_uid) return true
  return Math.abs((cur.timestamp || 0) - (prev.timestamp || 0)) > 300  // >5 min
}

// 单聊的 conv_id 形如 "0:1:uidA:uidB"，群聊是纯数字雪花 ID。
const isGroupConv = computed(() => {
  const id = props.conversation?.conv_id || ''
  return !!id && !id.includes(':')
})

function displayName(msg) {
  if (selfUid.value && msg.sender_uid === selfUid.value) {
    const u = userCache[msg.sender_uid]
    return u?.nickname || '我'
  }
  const u = userCache[msg.sender_uid]
  if (u?.nickname) return u.nickname
  if (msg.sender_name && msg.sender_name !== '__self__') return msg.sender_name
  // 群聊里回退成会话名 = 把每个不认识的成员都显示成群名，不同的人会糊成同一个。
  // 单聊没这个问题（会话名就是对方昵称）。
  if (props.embeddedMessages || isGroupConv.value) {
    return msg.sender_uid ? `用户${msg.sender_uid.slice(-6)}` : '群成员'
  }
  return props.conversation?.name || '对方'
}

function getAvatarUrl(msg) {
  return resolveAvatarUrl(userCache[msg.sender_uid]?.avatar_url)
}

async function fetchUserInfo(uid) {
  if (!uid || userCache[uid]) return
  try {
    const res = await fetch(`/api/users/${uid}`)
    if (res.ok) {
      const data = await res.json()
      userCache[uid] = data
    }
  } catch {}
}

async function loadUserInfoForMessages(msgList) {
  const uids = new Set()
  for (const msg of msgList) {
    if (msg.sender_uid && !userCache[msg.sender_uid]) uids.add(msg.sender_uid)
  }
  await Promise.all(Array.from(uids).map(uid => fetchUserInfo(uid)))
}

function pickSelf(uid) {
  selfUid.value = uid || ''
  if (uid) {
    localStorage.setItem('selfUid', uid)
  } else {
    localStorage.removeItem('selfUid')
  }
  showPicker.value = false
}

// 系统消息引用的视频：异步加载分享消息的标题和封面
async function loadSysRefs(msgList) {
  for (const msg of msgList) {
    if (msg.msg_type !== 0 || sysRefCache[msg.msg_id]) continue
    const smids = extractServerMsgIds(msg)
    if (!smids.length) continue
    for (const smid of smids) {
      try {
        const res = await fetch(`/api/messages/srv_${smid}`)
        if (!res.ok) continue
        const refMsg = await res.json()
        const info = getShareInfo(refMsg)
        if (info.title || info.cover) {
          sysRefCache[msg.msg_id] = { ...info, serverId: smid }
          break
        }
      } catch {}
    }
  }
}

function openSystemReference(msg) {
  const target = sysRefCache[msg.msg_id]
  if (props.embeddedMessages) {
    if (target?.itemId) window.open(`https://www.douyin.com/video/${target.itemId}`, '_blank')
  } else if (target?.serverId) jumpToRefMsg({ server_id: target.serverId })
}

async function openVideoReference(msg) {
  if (props.embeddedMessages) return openShare(msg)
  const ref = getRefMsg(msg)
  if (ref?.server_id) return jumpToRefMsg(ref)
  const convId = props.conversation?.conv_id
  try {
    const res = await fetch(`/api/messages/${encodeURIComponent(msg.msg_id)}/referenced-video`)
    if (!res.ok) throw new Error()
    const target = await res.json()
    if (props.conversation?.conv_id !== convId) return
    return jumpToRefMsg({ server_id: target.msg_id.replace(/^srv_/, '') })
  } catch {
    if (props.conversation?.conv_id === convId) referenceError.value = '引用的消息未归档，无法定位'
  }
}

// 右键消息体 → 全选其内容（让浏览器原生右键菜单的"复制"直接生效）
function selectMsgContent(e) {
  const body = e.currentTarget
  if (!body) return
  // 优先精确选中消息内容容器（避开 sender / time）
  const content = body.querySelector(
  ':scope > .msg-bubble, :scope > .msg-share-card, :scope > .msg-share-comment, :scope > .msg-media'
  )
  const target = content || body
  const range = document.createRange()
  range.selectNodeContents(target)
  const sel = window.getSelection()
  sel.removeAllRanges()
  sel.addRange(range)
  // 不阻止默认事件 —— 浏览器原生菜单照常出现，"Copy" 即可
}

// 右键系统消息 → 全选
function selectSystemContent(e) {
  const el = e.currentTarget
  if (!el) return
  const range = document.createRange()
  range.selectNodeContents(el)
  const sel = window.getSelection()
  sel.removeAllRanges()
  sel.addRange(range)
}

// 高亮的消息 ID
const highlightMsgId = ref(null)

// Lightbox state (the overlay + ESC handling live in MessageLightbox)
const loadError = ref('')
const referenceError = ref('')
let messageRequestId = 0
const lightboxSrc = ref(null)
function openLightbox(src) {
  if (src) lightboxSrc.value = src
}

async function jumpToRefMsg(ref) {
  if (!ref || !ref.server_id || !props.conversation) return
  referenceError.value = ''
  const convId = props.conversation.conv_id
  const canonicalId = `srv_${ref.server_id}`
  const embedded = props.embeddedMessages?.find(m => m.msg_id === canonicalId || m.msg_id.endsWith('/' + canonicalId))
  const msgId = embedded?.msg_id || canonicalId
  // 锁定滚动，防止无限加载干扰
  scrollLocked = true
  try {
    // 先检查当前已加载的消息中是否有目标
    const existing = listRef.value?.querySelector(`[data-msgid="${msgId}"]`)
    if (existing) {
      existing.scrollIntoView({ block: 'center' })
      highlightMsgId.value = msgId
      setTimeout(() => { highlightMsgId.value = null }, 2000)
      return
    }
    if (isStatic.value) {
      referenceError.value = '引用的消息不在当前记录中'
      return
    }
    // 需要加载目标消息附近的消息
    const res = await fetch(`/api/messages/${msgId}`)
    if (!res.ok) throw new Error()
    const msg = await res.json()
    if (props.conversation?.conv_id !== convId) return
    if (msg.conv_id !== convId || !msg.seq) throw new Error()
    const targetSeq = Math.max(0, msg.seq - 50)
    loading.value = true
    const url = `/api/conversations/${props.conversation.conv_id}/messages?page_size=100&after_seq=${targetSeq}`
    const res2 = await fetch(url)
    if (!res2.ok) throw new Error()
    const data = await res2.json()
    if (props.conversation?.conv_id !== convId) return
    clearCjCache()
    loading.value = false
    messages.value = data.items
    total.value = data.total
    hasOlder.value = data.has_older ?? true
    hasNewer.value = data.has_newer ?? true
    loadUserInfoForMessages(data.items)
    loadSysRefs(data.items)
    await nextTick()
    const el = listRef.value?.querySelector(`[data-msgid="${msgId}"]`)
    if (el) {
      el.scrollIntoView({ block: 'center' })
      highlightMsgId.value = msgId
      setTimeout(() => { highlightMsgId.value = null }, 2000)
    }
  } catch {
    referenceError.value = '引用的消息未归档或加载失败，无法定位'
  } finally {
    loading.value = false
    setTimeout(() => { scrollLocked = false }, 300)
  }
}

// 打开分享视频
function openShare(msg) {
  const info = getShareInfo(msg)
  if (info.productUrl) {
    window.open(info.productUrl, '_blank')
  } else if (info.itemId) {
    window.open(`https://www.douyin.com/video/${info.itemId}`, '_blank')
  }
}

async function fetchSenders(convId) {
  try {
    const res = await fetch(`/api/conversations/${convId}/senders`)
    senders.value = await res.json()
    // 预加载发送者的用户信息
    for (const s of senders.value) {
      fetchUserInfo(s.sender_uid)
    }
  } catch {}
}

async function fetchMessages(convId, beforeSeq = null, afterSeq = null, replace = false) {
  const requestId = ++messageRequestId
  loading.value = true
  loadError.value = ''
  let url = `/api/conversations/${convId}/messages?page_size=100`
  if (beforeSeq !== null) url += `&before_seq=${beforeSeq}`
  if (afterSeq !== null) url += `&after_seq=${afterSeq}`
  let data
  try {
    const res = await fetch(url)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    data = await res.json()
    if (requestId !== messageRequestId || props.conversation?.conv_id !== convId) return
    if (!Array.isArray(data.items)) throw new Error('消息响应格式错误')
  } catch (e) {
    if (requestId !== messageRequestId || props.conversation?.conv_id !== convId) return
    loadError.value = `消息加载失败（${e.message}），请重试；持续失败请查看服务端日志`
    // Don't leave the spinner (and scroll lock) stuck forever on a failed load.
    loading.value = false
    scrollLocked = false
    console.error('加载消息失败', e)
    return
  }
  loading.value = false

  // 清理缓存
  clearCjCache()

  scrollLocked = true
  if (beforeSeq === null && afterSeq === null) {
    // 初始加载（最新消息）
    messages.value = data.items
    hasOlder.value = !!data.has_older
    hasNewer.value = !!data.has_newer
    await nextTick()
    if (listRef.value) listRef.value.scrollTop = listRef.value.scrollHeight
  } else if (replace) {
    // 从搜索、日期或引用结果跳入会话中间；页面两侧都可能还有消息。
    messages.value = data.items
    hasOlder.value = !!data.has_older
    hasNewer.value = !!data.has_newer
    await nextTick()
    if (afterSeq === 0 && listRef.value) listRef.value.scrollTop = 0
  } else if (afterSeq !== null) {
    // 向下加载更新的消息。
    messages.value = [...messages.value, ...data.items]
    hasNewer.value = data.items.length > 0 && !!data.has_newer
  } else {
    // 加载更早的消息（向上加载更多）
    const list = listRef.value
    const prevHeight = list ? list.scrollHeight : 0
    messages.value = [...data.items, ...messages.value]
    hasOlder.value = data.items.length > 0 && !!data.has_older
    await nextTick()
    if (list) list.scrollTop = list.scrollHeight - prevHeight
  }
  setTimeout(() => { scrollLocked = false }, 200)

  total.value = data.total
  // 异步加载用户信息（头像、昵称）
  loadUserInfoForMessages(data.items)
  // 异步加载系统消息引用的视频
  loadSysRefs(data.items)
}

function loadOlder() {
  if (!props.conversation || !messages.value.length || !hasOlder.value || loading.value) return
  const minSeq = Math.min(...messages.value.map(m => m.seq))
  fetchMessages(props.conversation.conv_id, minSeq)
}

function loadNewer() {
  if (!props.conversation || !messages.value.length || !hasNewer.value || loading.value) return
  const maxSeq = Math.max(...messages.value.map(m => m.seq))
  fetchMessages(props.conversation.conv_id, null, maxSeq)
}

// 截图模式：一次性加载闭区间消息，等用户信息与引用卡片就绪后通知父组件
async function fetchStaticRange(convId) {
  loading.value = true
  try {
    const { startSeq, endSeq } = props.staticRange
    const res = await fetch(
      `/api/conversations/${convId}/messages/range?start_seq=${startSeq}&end_seq=${endSeq}`
    )
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()
    clearCjCache()
    messages.value = data.items
    total.value = data.total
    hasOlder.value = false
    hasNewer.value = false
    await loadUserInfoForMessages(data.items)
    await loadSysRefs(data.items)
  } catch (e) {
    console.error('加载消息失败', e)
  } finally {
    loading.value = false
  }
  await nextTick()
  emit('staticLoaded')
}

async function jumpToTop() {
  if (!props.conversation) return
  await fetchMessages(props.conversation.conv_id, null, 0, true)
}

async function jumpToBottom() {
  if (!props.conversation) return
  // 重新加载最新消息（无 beforeSeq / afterSeq）
  await fetchMessages(props.conversation.conv_id)
}

// 无限滚动：滚动到顶部或底部时自动加载更多
let scrollDebounce = null
function onListScroll() {
  if (scrollDebounce || scrollLocked) return
  const list = listRef.value
  if (!list || loading.value) return
  if (!props.conversation) return  // scroll event after the conversation was cleared
  const threshold = 100
  // 滚到顶部附近 → 加载更早消息
  if (list.scrollTop < threshold && hasOlder.value) {
    scrollDebounce = true
    loadOlder()
    setTimeout(() => { scrollDebounce = false }, 500)
  }
  // 滚到底部附近 → 加载更新消息。
  if (list.scrollHeight - list.scrollTop - list.clientHeight < threshold && hasNewer.value) {
    scrollDebounce = true
    loadNewer()
    setTimeout(() => { scrollDebounce = false }, 500)
  }
}

onMounted(() => {
  if (isStatic.value) return
  // 延迟绑定，等 listRef 准备好
  const tryBind = () => {
    if (listRef.value) {
      listRef.value.addEventListener('scroll', onListScroll, { passive: true })
    } else {
      setTimeout(tryBind, 200)
    }
  }
  tryBind()
})
onUnmounted(() => {
  if (listRef.value) {
    listRef.value.removeEventListener('scroll', onListScroll)
  }
  for (const audio of voiceAudioRefs.values()) audio.pause()
  voiceAudioRefs.clear()
  playingVoiceId.value = null
})

function formatTime(ts) {
  if (!ts) return ''
  const d = new Date(ts * 1000)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  const time = d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
  if (isToday) return time
  return d.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }) + ' ' + time
}

// Highlight the active search term inside a message bubble.
function highlightText(text) {
  return _highlightText(text, props.searchHighlight)
}

function onImgError(e) {
  e.target.style.display = 'none'
}

watch(() => props.conversation, (conv) => {
  referenceError.value = ''
  loadError.value = ''
  messageRequestId++
  if (props.embeddedMessages) return
  if (conv) {
    messages.value = []
    hasOlder.value = false
    hasNewer.value = false
    clearCjCache()
    if (isStatic.value) {
      fetchStaticRange(conv.conv_id)
      return
    }
    fetchSenders(conv.conv_id)
    // 如果有 jumpToSeq，由 jumpToSeq watcher 处理加载
    if (!props.jumpToSeq) {
      fetchMessages(conv.conv_id)
    }
  }
}, { immediate: true })

watch(() => props.embeddedMessages, (items) => {
  if (!items) return
  messages.value = items
  total.value = items.length
  hasOlder.value = false
  hasNewer.value = false
  loadUserInfoForMessages(items)
}, { immediate: true })

watch(() => props.selfUidOverride, (uid) => { selfUid.value = uid || '' })

watch(() => props.jumpToSeq, async (seq) => {
  if (seq && props.conversation) {
    messages.value = []
    clearCjCache()
    const targetSeq = Math.max(0, seq - 50)
    await fetchMessages(props.conversation.conv_id, null, targetSeq, true)
    await nextTick()
    // 精确滚动到目标消息并高亮
    const targetMsg = messages.value.find(m => m.seq === seq)
    if (targetMsg && listRef.value) {
      const el = listRef.value.querySelector(`[data-msgid="${targetMsg.msg_id}"]`)
      if (el) {
        el.scrollIntoView({ block: 'center' })
        highlightMsgId.value = targetMsg.msg_id
        setTimeout(() => { highlightMsgId.value = null }, 3000)
      }
    }
    emit('jumped')
  }
})
</script>

<style scoped>
.msg-profile-card { display: flex; align-items: center; gap: 12px; width: 280px; max-width: 100%; padding: 14px; background: var(--bg-secondary); color: var(--text-primary); border: 1px solid var(--border-color); border-radius: var(--radius); text-decoration: none; }
.msg-profile-card img { width: 56px; height: 56px; border-radius: 50%; object-fit: cover; }
.msg-profile-card strong { font-size: 15px; }
.msg-profile-card div div, .msg-profile-card small { font-size: 12px; color: var(--text-secondary); margin-top: 5px; }

.msg-panel {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  background: var(--bg-primary);
  position: relative;
}

.msg-empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--text-muted);
  gap: 12px;
}
.msg-empty-icon {
  font-size: 48px;
}

.msg-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px;
  border-bottom: 1px solid var(--border-color);
  background: var(--bg-secondary);
  gap: 12px;
}
.msg-header h3 {
  font-size: 15px;
  font-weight: 600;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.msg-total {
  font-size: 12px;
  color: var(--text-muted);
  white-space: nowrap;
  flex-shrink: 0;
}

.msg-pick-self {
  white-space: nowrap;
  flex-shrink: 0;
  margin-left: auto;
  padding: 4px 12px;
  border: 1px solid var(--border-color);
  border-radius: 14px;
  background: var(--bg-tertiary);
  color: var(--text-primary);
  font-size: 12px;
  cursor: pointer;
}
.msg-pick-self:hover { border-color: var(--accent); }
.msg-pick-self.picked { border-color: var(--accent); color: var(--accent); }

/* UID 选择弹窗 */
.picker-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  z-index: 200;
  display: flex;
  align-items: center;
  justify-content: center;
}
.picker-dialog {
  background: var(--bg-secondary);
  border-radius: 12px;
  padding: 24px;
  min-width: min(280px, 90vw);
  max-width: 90vw;
  box-shadow: 0 8px 30px rgba(0,0,0,0.4);
}
.picker-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 4px;
}
.picker-hint {
  font-size: 12px;
  color: var(--text-muted);
  margin-bottom: 16px;
}
.picker-option {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 14px;
  border: 1px solid var(--border-color);
  border-radius: 8px;
  margin-bottom: 8px;
  cursor: pointer;
  transition: border-color 0.15s;
}
.picker-option:hover { border-color: var(--accent); }
.picker-option.active { border-color: var(--accent); background: var(--bg-tertiary); }
.picker-uid { font-family: monospace; font-size: 13px; }
.picker-count { font-size: 12px; color: var(--text-muted); }
.picker-clear {
  width: 100%;
  margin-top: 8px;
  padding: 6px;
  border: none;
  background: none;
  color: var(--text-muted);
  font-size: 12px;
  cursor: pointer;
}
.picker-clear:hover { color: var(--accent); }

.msg-list {
  flex: 1;
  overflow-y: auto;
  padding: 16px 20px 32px;
}

/* 截图模式：容器随内容自然撑开，不滚动，供整页截图 */
.msg-panel-static {
  flex: none;
  min-height: auto;
  height: auto;
}
.msg-list-static {
  flex: none;
  overflow: visible;
  height: auto;
}

.msg-loading, .msg-no-data {
  text-align: center;
  color: var(--text-muted);
  padding: 20px;
  font-size: 13px;
}

.msg-load-more {
  text-align: center;
  color: var(--accent);
  padding: 16px 10px;
  margin: 8px 0;
  cursor: pointer;
  font-size: 13px;
  flex-shrink: 0;
}
.msg-load-more:hover {
  color: var(--accent-hover);
}

.msg-jump-fab {
  position: absolute;
  right: 32px;
  z-index: 100;
  padding: 8px 18px;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 20px;
  font-size: 13px;
  cursor: pointer;
  box-shadow: 0 2px 10px rgba(0,0,0,0.35);
}
.msg-jump-fab:hover { opacity: 0.85; }
.msg-jump-top { bottom: 28px; }
.msg-jump-bottom { bottom: 28px; }

/* 系统消息 */
.msg-item.msg-system {
  max-width: 100%;
  justify-content: center;
}
.msg-system-block {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  max-width: 80%;
}
.msg-system-text {
  font-size: 12px;
  color: var(--text-secondary);
  background: color-mix(in srgb, var(--text-primary) 6%, transparent);
  padding: 4px 14px;
  border-radius: 999px;
  text-align: center;
}
/* 一起看视频邀请卡片 */
.msg-watch-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 14px 8px 10px;
  background: color-mix(in srgb, var(--accent) 10%, var(--bg-secondary));
  border: 1px solid color-mix(in srgb, var(--accent) 30%, transparent);
  border-radius: var(--radius);
  max-width: 280px;
}
.msg-watch-icon {
  flex-shrink: 0;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--accent);
  color: #fff;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding-left: 2px;
}
.msg-watch-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary);
}
.msg-watch-sub {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 1px;
}
.msg-system-ref {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  cursor: pointer;
  max-width: 280px;
  transition: border-color 0.15s;
}
.msg-system-ref:hover {
  border-color: var(--accent);
}
.msg-system-ref-cover {
  width: 36px;
  height: 36px;
  border-radius: 4px;
  object-fit: cover;
  flex-shrink: 0;
}
.msg-system-ref-title {
  font-size: 12px;
  color: var(--text-secondary);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.3;
}

.msg-item {
  display: flex;
  gap: 10px;
  margin-bottom: 3px;
  max-width: 74%;
  transition: background 0.3s;
}
/* first message of a sender group gets breathing room above it */
.msg-item.group-start {
  margin-top: 14px;
}
/* Target only this row: forwarded dialogs contain another MessageList. */
/* continuation messages hide the repeated avatar + name and sit tight */
.msg-item.msg-grouped > .msg-avatar {
  visibility: hidden;
}
.msg-item.msg-grouped > .msg-body > .msg-sender {
  display: none;
}
.msg-item.msg-highlight {
  background: color-mix(in srgb, var(--highlight) 22%, transparent);
  border-radius: var(--radius);
  animation: highlight-fade 2s ease-out;
}
@keyframes highlight-fade {
  0% { background: color-mix(in srgb, var(--highlight) 40%, transparent); }
  100% { background: transparent; }
}
.msg-item.msg-self {
  flex-direction: row-reverse;
  margin-left: auto;
}

.msg-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 600;
  flex-shrink: 0;
  margin-top: 2px;
  overflow: hidden;
}
.msg-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}
.msg-avatar span {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
}

.msg-body {
  min-width: 0;
}

.msg-sender {
  font-size: 12px;
  color: var(--text-muted);
  margin-bottom: 3px;
}
.msg-item.msg-self > .msg-body > .msg-sender {
  text-align: right;
}

.msg-bubble {
  background: var(--bg-message-other);
  padding: 9px 13px;
  border-radius: var(--bubble-radius);
  border-top-left-radius: 4px;
  font-size: 14px;
  line-height: 1.55;
  word-break: break-word;
  white-space: pre-wrap;
  box-shadow: var(--shadow-sm);
  border: 1px solid color-mix(in srgb, var(--text-primary) 5%, transparent);
}
.msg-item.msg-self > .msg-body > .msg-bubble {
  background: var(--bg-message-self);
  color: var(--text-on-self);
  border: none;
  border-top-left-radius: var(--bubble-radius);
  border-top-right-radius: 4px;
}

/* 分享卡片 */
.msg-share-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  background: var(--bg-message-other);
  border-radius: 10px;
  border-top-left-radius: 2px;
  padding: 10px 12px;
  cursor: pointer;
  transition: filter 0.15s;
  max-width: 320px;
  border-left: 3px solid var(--accent);
}
.msg-share-comment {
  font-size: 14px;
  line-height: 1.5;
  word-break: break-word;
}
.msg-share-comment-user {
  font-weight: 600;
  color: var(--accent);
}
.msg-share-comment-img {
  display: block;
  max-width: 180px;
  max-height: 180px;
  border-radius: 6px;
  margin-top: 6px;
  object-fit: contain;
}
.msg-share-card-inner {
  display: flex;
  gap: 10px;
}
.msg-share-card:hover {
  filter: brightness(1.1);
}
.msg-item.msg-self > .msg-body > .msg-share-card {
  background: var(--bg-message-self);
  border-top-left-radius: 10px;
  border-top-right-radius: 2px;
}
.msg-share-card-body {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.msg-share-card-title {
  font-size: 13px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  word-break: break-word;
}
.msg-share-card-author {
  font-size: 11px;
  color: var(--text-muted);
  margin-top: auto;
}
.msg-share-card-cover {
  width: 60px;
  height: 60px;
  border-radius: 6px;
  object-fit: cover;
  flex-shrink: 0;
  align-self: center;
}
.msg-share-card-ref {
  background: var(--bg-tertiary);
  border-radius: 6px;
  padding: 6px 10px;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-secondary);
}
.msg-share-card-ref-icon {
  opacity: 0.6;
}

/* 引用/回复消息 */
.msg-ref-quote {
  padding: 6px 10px;
  margin-bottom: 4px;
  background: var(--bg-tertiary);
  border-left: 2px solid var(--text-muted);
  border-radius: 4px;
  font-size: 12px;
  color: var(--text-muted);
  max-width: 300px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
  transition: background 0.2s;
}
.msg-ref-quote:hover {
  background: var(--border-color);
}
.msg-ref-name {
  font-weight: 600;
  color: var(--text-secondary);
}
.msg-ref-content {
  opacity: 0.85;
}

/* 语音消息：沿用普通消息气泡，并在播放器与转写之间分隔 */
.msg-voice-bubble {
  min-width: 176px;
  max-width: 360px;
  padding: 8px 10px 9px;
}
.msg-voice-player {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 32px;
}
.msg-voice-play {
  width: 32px;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--text-primary);
  color: var(--bg-primary);
  box-shadow: none;
  cursor: pointer;
  flex: 0 0 auto;
  transition: transform 0.15s, opacity 0.15s;
}
.msg-voice-play svg { width: 16px; height: 16px; fill: currentColor; }
.msg-voice-play:hover:not(:disabled),
.msg-voice-play.playing {
  transform: scale(1.03);
  opacity: 0.78;
}
.msg-item.msg-self > .msg-body > .msg-voice-bubble .msg-voice-play {
  background: color-mix(in srgb, var(--text-on-self) 94%, transparent);
  color: var(--accent);
}
.msg-item.msg-self > .msg-body > .msg-voice-bubble .msg-voice-play:hover:not(:disabled),
.msg-item.msg-self > .msg-body > .msg-voice-bubble .msg-voice-play.playing {
  opacity: 0.8;
}
.msg-voice-play:disabled {
  opacity: 0.45;
  cursor: default;
  box-shadow: none;
}
.msg-voice-play:focus-visible {
  outline: 2px solid var(--accent);
  outline-offset: 2px;
}
.msg-voice-wave {
  display: flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  flex: 0 0 auto;
}
.msg-voice-wave i {
  display: block;
  width: 2.5px;
  height: 10px;
  border-radius: 999px;
  background: var(--text-primary);
  opacity: 0.88;
  transform-origin: center;
  transition: opacity 0.2s, background 0.2s;
}
.msg-voice-wave i:nth-child(1) { height: 8px; }
.msg-voice-wave i:nth-child(2) { height: 14px; }
.msg-voice-wave i:nth-child(3) { height: 11px; }
.msg-voice-wave i:nth-child(4) { height: 16px; }
.msg-voice-wave i:nth-child(5) { height: 10px; }
.msg-voice-wave i:nth-child(6) { height: 18px; }
.msg-voice-wave i:nth-child(7) { height: 12px; }
.msg-voice-wave i:nth-child(8) { height: 21px; }
.msg-voice-wave i:nth-child(9) { height: 14px; }
.msg-voice-wave i:nth-child(10) { height: 9px; }
.msg-voice-wave i:nth-child(11) { height: 17px; }
.msg-voice-wave i:nth-child(12) { height: 12px; }
.msg-voice-wave i:nth-child(13) { height: 19px; }
.msg-item.msg-self > .msg-body > .msg-voice-bubble .msg-voice-wave i {
  background: color-mix(in srgb, var(--text-on-self) 90%, transparent);
  opacity: 0.9;
}
@keyframes voice-wave-pulse {
  0%, 100% { transform: scaleY(0.58); opacity: 0.58; }
  50% { transform: scaleY(1); opacity: 1; }
}
.msg-voice-player.playing .msg-voice-wave i {
  animation: voice-wave-pulse 0.9s ease-in-out infinite alternate;
}
.msg-voice-player.playing .msg-voice-wave i:nth-child(2n) { animation-delay: -0.25s; }
.msg-voice-player.playing .msg-voice-wave i:nth-child(3n) { animation-delay: -0.5s; }
@media (prefers-reduced-motion: reduce) {
  .msg-voice-player.playing .msg-voice-wave i { animation: none; }
}
.msg-voice-bubble audio {
  display: none;
}
.msg-voice-dur {
  margin-left: 4px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-muted);
  white-space: nowrap;
  text-align: right;
}
.msg-item.msg-self > .msg-body > .msg-voice-bubble .msg-voice-dur {
  color: color-mix(in srgb, var(--text-on-self) 76%, transparent);
}
.msg-voice-divider {
  border-top: 1px solid color-mix(in srgb, var(--text-primary) 16%, transparent);
  margin: 8px 0 7px;
}
.msg-item.msg-self > .msg-body > .msg-voice-bubble .msg-voice-divider {
  border-top-color: color-mix(in srgb, var(--text-on-self) 25%, transparent);
}
.msg-voice-transcript {
  color: inherit;
  font-size: 14px;
  line-height: 1.55;
  white-space: pre-wrap;
  word-break: break-word;
}

/* 表情/图片 */
.msg-media img {
  max-width: 240px;
  max-height: 240px;
  border-radius: 8px;
  cursor: pointer;
}
.msg-media video {
  max-width: 280px;
  max-height: 360px;
  border-radius: 8px;
  background: #000;
}
.msg-inline-pic {
  opacity: 0.85;
  filter: blur(0.5px);
}
.msg-media-missing {
  font-size: 12px;
  color: var(--text-muted);
  padding: 8px 12px;
  background: var(--bg-tertiary);
  border-radius: 8px;
}
/* 视频封面 + 时长 overlay */
.msg-video-poster {
  position: relative;
  display: inline-block;
  cursor: pointer;
}
.msg-video-player {
  max-width: 280px;
  max-height: 360px;
  border-radius: 8px;
  background: #000;
}
.msg-video-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
  border-radius: 8px;
  background: linear-gradient(rgba(0,0,0,0) 60%, rgba(0,0,0,0.5));
}
.msg-video-play {
  font-size: 36px;
  color: rgba(255,255,255,0.92);
  text-shadow: 0 2px 8px rgba(0,0,0,0.6);
  line-height: 1;
}
.msg-video-dur {
  position: absolute;
  right: 8px;
  bottom: 6px;
  background: rgba(0,0,0,0.55);
  color: #fff;
  font-size: 12px;
  padding: 2px 6px;
  border-radius: 3px;
}

.msg-time {
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 3px;
}
.msg-item.msg-self > .msg-body > .msg-time {
  text-align: right;
}
.msg-recalled-tag {
  font-size: 10px;
  color: #e5534b;
  background: rgba(229, 83, 75, 0.1);
  padding: 1px 5px;
  border-radius: 3px;
  margin-right: 4px;
}

/* 手机端：收紧边距、放宽气泡、媒体不超出屏幕。
   截图模式（msg-panel-static，默认 520px 宽）不吃这些规则，保持导出图样式不变。 */
@media (max-width: 768px) {
  .msg-header {
    padding: 8px 12px;
    gap: 8px;
  }
  .msg-header h3 { font-size: 14px; }
  .msg-pick-self { padding: 4px 10px; }

  .msg-panel:not(.msg-panel-static) .msg-list { padding: 8px 10px 24px; }
  .msg-panel:not(.msg-panel-static) .msg-item {
    gap: 8px;
    max-width: 88%;
  }
  .msg-panel:not(.msg-panel-static) .msg-item.msg-system { max-width: 100%; }
  .msg-panel:not(.msg-panel-static) .msg-item.group-start { margin-top: 12px; }
  .msg-panel:not(.msg-panel-static) .msg-avatar {
    width: 32px;
    height: 32px;
  }
  .msg-panel:not(.msg-panel-static) .msg-system-block { max-width: 92%; }

  .msg-panel:not(.msg-panel-static) .msg-media img { max-width: min(240px, 60vw); }
  .msg-panel:not(.msg-panel-static) .msg-media video,
  .msg-panel:not(.msg-panel-static) .msg-video-player { max-width: min(280px, 64vw); }
  .msg-panel:not(.msg-panel-static) .msg-share-card { max-width: min(320px, 70vw); }
  .msg-panel:not(.msg-panel-static) .msg-ref-quote { max-width: min(300px, 70vw); }
  .msg-panel:not(.msg-panel-static) .msg-voice-bubble { max-width: min(360px, 70vw); }

  .msg-jump-fab {
    right: 14px;
    padding: 8px 14px;
  }
  .msg-jump-top, .msg-jump-bottom { bottom: 18px; }
}
</style>
